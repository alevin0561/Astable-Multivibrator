Project Name: Simulation of Astable Multivibrator Circuit
Project Version: #09ec1d3d
Project Url: https://www.flux.ai/alexlevine2020/simulation-of-astable-multivibrator-circuit

Project Description:
A simulated blinking LED circuit using an astable multivibrator a.k.a "flip-flop" as a square wave generator. It also includes PCB layout of the project.


